<?php


include 'connection.php';

$author_name = $_POST['author_name'];
$book_name = $_POST['book_name'];
$book_no = $_POST['book_no'];

$branch = $_POST['branch'];
$sem = $_POST['sem'];
$adding_date = $_POST['adding_date'];


        

$sql = "INSERT INTO books_detail (author_name,book_name,book_no,branch,sem,adding_date)
VALUES ('$author_name', '$book_name','$book_no', '$branch', '$sem', '$adding_date');";


if ($conn->multi_query($sql) === TRUE) {



    echo "<script>window.location='/wellcome.php'</script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
