<?php


include 'connection.php';

$student_roll = $_POST['student_roll'];
$student_name = $_POST['student_name'];
$book_name = $_POST['book_name'];
$book_no = $_POST['book_no'];
$branch = $_POST['branch'];
$sem = $_POST['sem'];
$issuing_date = $_POST['issuing_date'];


$sql = "INSERT INTO books_issue (student_name,student_roll,book_name,book_no,branch,sem,issuing_date)
VALUES ('$student_name','$student_roll', '$book_name','$book_no', '$branch', '$sem', '$issuing_date');";


if ($conn->multi_query($sql) === TRUE) {

 echo "<script>window.location='/issued_books.php'</script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
