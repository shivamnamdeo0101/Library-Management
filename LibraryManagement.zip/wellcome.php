
<!------------------------------------------------------------SESION------------------------------------------->

<?php
    session_start();

    if(isset($_SESSION['User']))
    {
        echo ' <font size="5">Well Come  ' . $_SESSION['User'].'<br/>  </font>';
        echo '<a href="logout.php?logout"><input type="submit" value="Logout"></a><br/><br/>';
    }
    else
    {
        header("location:index.php");
    }

?>
<!------------------------------------------------------------SESION------------------------------------------->
<html>

<head>

<title>Library Management | Home</title>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" ></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" ></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

</head>

<body>
<h1 align="center">All Books</h1><br>

<input type="text" class="form-control" id="myInput" onkeyup="myFunction()" placeholder="Search For Books.." title="Type in a name">
<br>
<!-----------------------------------------------------NAV BAR-------------------------------------------->

<nav class="navbar navbar-light bg-light">
	<a class="navbar-brand" href="#"><button type="button" class="btn btn-primary">Home</button></a>
	<a class="navbar-brand" href="#"><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal_issue">Issue Books</button></a>
	<a class="navbar-brand" href="issued_books.php"><button type="button" class="btn btn-primary">Issued Books</button></a>
	<a class="navbar-brand" href="#"><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal_book_add">Add Book</button></a>
	
	
</nav>

<br>
<!---------------------------------------------NAV BAR------------------------------------------------>




<!--------------------------------------------TABLE ---------------------------------------->

  <div>
 <div>
 
 <table  class="table" id="myTable">
 
 <tr>
 
  <th>Book Name</th> 
 <th>S. No.</th> 
  <th>Author Name</th> 
  <th>Book No.</th>
  <th>Branch</th> 
  <th>Semester</th> 
  <th>Adding Date</th> 
  <th>Delete</th> 
  <th>Update</th> 
 </tr >

  <?php

  include 'conn.php'; 
 $q = "select * from books_detail ";

  $query = mysqli_query($con,$q);

  $count=0;
  while($res = mysqli_fetch_array($query)){$count++;
 ?>
 <tr>
 <td> <?php echo $res['book_name'];  ?> </td>
<td> <?php echo $count; ?> </td>

 <td> <?php echo $res['author_name'];  ?> </td>
  <td> <?php echo $res['book_no'];  ?> </td>
 <td> <?php echo $res['branch'];  ?> </td>
 <td> <?php echo $res['sem'];  ?> </td>
 <td> <?php echo $res['adding_date'];  ?> </td>
  
 <td> <a href="book_delete.php?id=<?php echo $res['id']; ?>" ><input type="submit" value="Delete" class="btn btn-danger"></a>  </td>
 <td> <a href="book_update.php?id=<?php echo $res['id']; ?>" ><input type="submit" value="Update" class="btn btn-success"></a>  </td>

 </tr>

  <?php 
 }
  ?>
 
 </table>  

  </div>
 </div>

  <script type="text/javascript">
 
 $(document).ready(function(){
 $('#tabledata').DataTable();
 }) 
 
 </script>



<!---------------------------------------Search Table--------------------------------->

<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
<!-----------------------------------Search Table-------------------------------------->

<!--------------------------------------------TABLE  --------------------------------------->


<!----------------------------Model Add Book----------------------------------------------------------->

<!-- Modal -->
<div class="modal fade" id="exampleModal_book_add" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Book In Libraray</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <!-------------------------------------------FORM---------------------------->



	
<form action="/books_detail/books_detail_insert.php" method="post">
    <table class="table">
   <tr>
    <td> 1.Book Name </td>
    <td><input type="text" name="book_name" required></td>
   </tr>
   <tr>
    <td>2.Author Name</td>
    <td><input type="text" name="author_name" required></td>
   </tr> 
    <tr>
    <td>3.Book No.</td>
    <td><input type="text" name="book_no" required></td>
   </tr> 
   <tr>
    <td>4.Branch</td>
    <td><input type="text" name="branch" required></td>
   </tr>
   <tr>
    <td>5.Semester</td>
    <td><input type="text" name="sem" required></td>
   </tr>
   <tr>
    <td>6.Adding Date</td>
    <td><input type="date" name="adding_date" required></td>
   </tr>
    
   <tr>
    <td><input type="submit" value="Submit" class="btn btn-primary"></td><td></td>
   </tr>
  </table>
</form>


<!---------------------------------------------  FORM---------------------------->

      </div>
      
    </div>
  </div>
</div>
<!--------------------------------------------Model Add Book------------------------------------------------>



<!----------------------------Model Issue Book----------------------------------------------------------->

<!-- Modal -->
<div class="modal fade" id="exampleModal_issue" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Book In </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <!-------------------------------------------FORM---------------------------->



	
<form action="/books_detail/books_issue_insert.php" method="post">
    <table class="table">
   <tr>
    <td>1.Student Roll No. </td>
    <td><input type="text" name="student_roll" required></td>
   </tr>
   <tr>
    <td>2.Student Name </td>
    <td><input type="text" name="student_name" required></td>
   </tr>
   <tr>
    <td>3.Book Name</td>
    <td><input type="text" name="book_name" required></td>
   </tr> 
    <tr>
    <td>4.Book No.</td>
    <td><input type="text" name="book_no" required></td>
   </tr> 
   <tr>
    <td>5.Branch</td>
    <td><input type="text" name="branch" required></td>
   </tr>
   <tr>
    <td>6.Semester</td>
    <td><input type="text" name="sem" required></td>
   </tr>
   <tr>
    <td>7.Issuing Date</td>
    <td><input type="date" name="issuing_date" required></td>
   </tr>
    
   <tr>
    <td><input type="submit" value="Submit" class="btn btn-primary"></td><td></td>
   </tr>
  </table>
</form>


<!---------------------------------------------  FORM---------------------------->

      </div>
      
    </div>
  </div>
</div>
<!--------------------------------------------Model Issue Book------------------------------------------------>

</body>

</html>

