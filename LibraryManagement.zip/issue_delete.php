<?php

include 'conn.php';

$id = $_GET['id'];

$q = " DELETE FROM `books_issue` WHERE id = $id ";

mysqli_query($con, $q);

header("Location: issued_books.php");

?>